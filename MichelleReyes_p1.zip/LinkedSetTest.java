package project1;

public class LinkedSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SetInterface<String> link1 = new LinkedSet<String>(); 
		SetInterface<String> link2 = new LinkedSet<String>();
		
		System.out.println("Print the string(s) within the link1:");
		link1.add("a"); 
		link1.add("b");
		link1.add("c");
		//type of object --- superclass >object 
	
			 for(Object i: link1.toArray()) {
				System.out.print(i + " ");
			
			 }
			 
		System.out.println();
		System.out.println();
		
		  System.out.println("Print the string(s) within the link2:");
		   link2.add("b");
			link2.add("c");
			link2.add("d");
			link2.add("e");
			
			for( Object i: link2.toArray()) {
				System.out.print(i + " ");
			}
		System.out.println();
		System.out.println();
			
		System.out.println("Get the union of 2 linked Sets:");
		   SetInterface<String> everything = link1.union(link2); 
		   for( Object i: everything.toArray()) {
				System.out.print(i + " ");
			}
		System.out.println();
		System.out.println();
		   
		System.out.println("Get the intersection of linked sets:");
		SetInterface<String> commonItems = link1.intersection(link2); 
		
		for( Object i: commonItems.toArray()) {
				System.out.print(i + " ");
			}
		System.out.println();
		System.out.println();
		
			 
		System.out.println("Get the difference of 2 linked sets: link1.diff(link2)");
		 SetInterface <String>leftOver1 = link1.difference(link2); 
		 for( Object i: leftOver1.toArray()) {
				System.out.print(i + " ");
			}
		 System.out.println();
		 System.out.println();
		 System.out.println("Get the difference of 2 linked sets: link2.diff(link1)");
		 SetInterface <String>leftOver2 = link2.difference(link1); 
		 for( Object i: leftOver2.toArray()) {
				System.out.print(i + " ");
			}
		System.out.println();
		System.out.println();
		
		//end
		
		System.out.println();
		System.out.println("Test all operations in link1");
				
			    System.out.println("Add the letter z:");
				link1.add("z");
		       System.out.println();
				//end
		       
		      System.out.println("Check if the linked set contains z:");
		       if(link1.contains("z")) {
		    	 System.out.println("true");	 
		     }
		     else {
		     System.out.println("not true");
		     }
		     System.out.println();
		     //end 
		     
		     System.out.println("Get the linked set current Size: ");
				System.out.println(link1.getCurrentSize());
				System.out.println();
				//end
				
		    System.out.println("Use the operation remove():");
		      link1.remove(); //last one of the set;returns boolean
		     //end
		     System.out.println();
		     
				System.out.println("Get the Linked set current Size(proof of remove()): ");
				System.out.println(link1.getCurrentSize());
				System.out.println();
				//end
				
				System.out.println("Remove a:");
		        link1.remove("a");
		   //end 
		   
		    System.out.println("Get the Linked set current Size: ");
			System.out.println(link1.getCurrentSize());
			System.out.println();
			//end
			
			 link1.clear();
			 //end
		   
			 System.out.println("Check if linked set is clear:");
				if(link1.isEmpty()) {
					System.out.println("Empty");
				}
				else {
					System.out.println("Not Empty");
				}
			System.out.println();
		   //end
		   
				System.out.println();
				System.out.println();
				
			//set2	
			
		   System.out.println("Test all operations in link2");

		    System.out.println("Add the letter z:");
		    link2.add("z");
		   System.out.println();
		//end

		    System.out.println("Check if the Linked set contains z:");
		   if(link2.contains("z")) {
		    System.out.println("true");	 
		   }
		   else {
		   System.out.println("not true");
		  }
		     System.out.println();
		//end 

		   System.out.println("Get the Linked set current Size: ");
		   System.out.println(link2.getCurrentSize());
		   System.out.println();
		//end

		   System.out.println("Use the operation remove():");
		   link2.remove(); //last one of the set;returns boolean
		//end
		   System.out.println();

		  System.out.println("Get the Linked set current Size(proof of remove()): ");
		  System.out.println(link2.getCurrentSize());
		  System.out.println();
		//end

		  System.out.println("Remove b:");
		   link2.remove("b");
		//end 

		 System.out.println("Get the Linked set current Size: ");
		 System.out.println(link2.getCurrentSize());
		 System.out.println();
		//end

		 link2.clear();
		//end

		 System.out.println("Check if Linked set is clear:");
		 if(link2.isEmpty()) {
			System.out.println("Empty");
		}
		 else {
			System.out.println("Not Empty");
		 }
		 System.out.println();
		//end


		System.out.println();
		System.out.println();

		//set2	
		 
		for( Object i: link2.toArray()) {
			System.out.println(i);
		}
		System.out.println();
		//end
			
				System.out.println();
				System.out.println();

				
	}

}
