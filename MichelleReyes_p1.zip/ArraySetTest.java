package project1;

public class ArraySetTest { //client program

	public static void main(String[] args) {
		
		SetInterface<String> set1 = new ResizeableArraySet<String>(); 
		SetInterface<String> set2 = new ResizeableArraySet<String>(); 
		//end
	
	System.out.println("Print the string(s) within the set1:");
		set1.add("a"); 
		set1.add("b");
		set1.add("c");
		//type of object --- superclass >object 
	for( Object i: set1.toArray()) {
			System.out.print(i + " ");
		}
   System.out.println();
   System.out.println();
		//end
   System.out.println("Print the string(s) within the set2:");
   set2.add("b");
	set2.add("c");
	set2.add("d");
	set2.add("e");
	
	for( Object i: set2.toArray()) {
		System.out.print(i + " ");
	}
System.out.println();
System.out.println();
 
	System.out.println("Get the union of 2 sets:");
   SetInterface<String> everyThing = set1.union(set2); 
   for( Object i: everyThing.toArray()) {
		System.out.print(i + " ");
	}
System.out.println();
System.out.println();
   
System.out.println("Get the intersection of 2 sets:");
SetInterface<String> commonItems = set1.intersection(set2); 
for( Object i: commonItems.toArray()) {
		System.out.print(i + " ");
	}
System.out.println();
System.out.println();

System.out.println("Get the difference of 2 sets: set1.diff(set2)");
 SetInterface <String>leftOver1 = set1.difference(set2); 
 for( Object i: leftOver1.toArray()) {
		System.out.print(i + " ");
	}
 System.out.println();
 System.out.println();
 System.out.println("Get the difference of 2 sets: set2.diff(set1)");
 SetInterface <String>leftOver2 = set2.difference(set1); 
 for( Object i: leftOver2.toArray()) {
		System.out.print(i + " ");
	}
System.out.println();
System.out.println();
//end
System.out.println();
System.out.println("Test all operations in set1");
		
	    System.out.println("Add the letter z:");
		set1.add("z");
       System.out.println();
		//end
       
      System.out.println("Check if the set contains z:");
       if(set1.contains("z")) {
    	 System.out.println("true");	 
     }
     else {
     System.out.println("not true");
     }
     System.out.println();
     //end 
     
     System.out.println("Get the Set current Size: ");
		System.out.println(set1.getCurrentSize());
		System.out.println();
		//end
		
    System.out.println("Use the operation remove():");
      set1.remove(); //last one of the set;returns boolean
     //end
     System.out.println();
     
		System.out.println("Get the Set current Size(proof of remove()): ");
		System.out.println(set1.getCurrentSize());
		System.out.println();
		//end
		
		System.out.println("Remove a:");
        set1.remove("a");
   //end 
   
    System.out.println("Get the Set current Size: ");
	System.out.println(set1.getCurrentSize());
	System.out.println();
	//end
	
	 set1.clear();
	 //end
   
	 System.out.println("Check if set is clear:");
		if(set1.isEmpty()) {
			System.out.println("Empty");
		}
		else {
			System.out.println("Not Empty");
		}
	System.out.println();
   //end
   
		System.out.println();
		System.out.println();
		
	//set2	
	
   System.out.println("Test all operations in set2");

    System.out.println("Add the letter z:");
    set2.add("z");
   System.out.println();
//end

    System.out.println("Check if the set contains z:");
   if(set2.contains("z")) {
    System.out.println("true");	 
   }
   else {
   System.out.println("not true");
  }
     System.out.println();
//end 

   System.out.println("Get the Set current Size: ");
   System.out.println(set2.getCurrentSize());
   System.out.println();
//end

   System.out.println("Use the operation remove():");
   set2.remove(); //last one of the set;returns boolean
//end
   System.out.println();

  System.out.println("Get the Set current Size(proof of remove()): ");
  System.out.println(set2.getCurrentSize());
  System.out.println();
//end

  System.out.println("Remove b:");
   set2.remove("b");
//end 

 System.out.println("Get the Set current Size: ");
 System.out.println(set2.getCurrentSize());
 System.out.println();
//end

 set2.clear();
//end

 System.out.println("Check if set is clear:");
 if(set2.isEmpty()) {
	System.out.println("Empty");
}
 else {
	System.out.println("Not Empty");
 }
 System.out.println();
//end


System.out.println();
System.out.println();

//set2	
 
for( Object i: set2.toArray()) {
	System.out.println(i);
}
System.out.println();
//end
	
		System.out.println();
		System.out.println();

		
	}

}
