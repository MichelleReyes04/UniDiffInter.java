package project1;

public class LinkedSet <T> implements SetInterface<T> {
private Node firstNode;       
private int  numberOfEntries;

//slide 53 
  
  public boolean add(T newEntry) {
    
	 if(contains(newEntry)) {
		 return false;
		 }
      Node newNode = new Node(newEntry);
     newNode.next = firstNode;         
      firstNode = newNode;      // new node is at beginning of chain
     numberOfEntries++;
    return true;
    } 

  public T remove() {
	 
	  T end = null;
	  if (firstNode != null) { 
		  end = firstNode.getData();
		  firstNode = firstNode.getNextNode(); 
		  numberOfEntries--;
	  } 
  return end;
  } 
  

  private Node getReferenceTo(T anEntry) {
	   boolean find = false;
	   Node currentNode = firstNode;
	    while(!find && (currentNode != null)) {
	     if (anEntry.equals(currentNode.getData())) {
	     find = true;
	    }
	     else {
	  currentNode = currentNode.getNextNode();
	    }
	    }
	  return currentNode;
	  }
 public LinkedSet() {   // constructors
	 
	  firstNode = null;
	  numberOfEntries = 0;
 }
 
  
  public boolean remove(T anEntry) {
	
  boolean result = false;
  Node findnod = getReferenceTo(anEntry);
  if (findnod != null)
  {
  // Replace located entry with entry in first node
	  findnod.setData(firstNode.getData()); 
 
  firstNode = firstNode.getNextNode(); 
 numberOfEntries--;
  result = true;
  } 
  return result;
  } 
  
  public boolean contains(T anEntry) {
	  boolean these = false;
	  Node current = firstNode;
	  
	  while(!these && (current != null)){
			  if(anEntry.equals(current.getData())){
				  these = true; 
			  }
			  else {
				  current = current.getNextNode();
			  }
  
	  }
	  return these;
  }

  public T[] toArray(){
	  @SuppressWarnings("unchecked")
		T[]yes = (T[])new Object[numberOfEntries];  
	   int i =0;
	   Node current1 = firstNode;
	   while((i < numberOfEntries)&& (current1 != null)) {
		   yes[i] = current1.getData();
		   i++;
		   current1 = current1.getNextNode(); //retrieve next node 
		   
	   }
	   return yes;
  }
  
  public void clear(){
	  while(!isEmpty())
	  remove();
	  } 
  
  
  public int getCurrentSize() {
		 return numberOfEntries;
	 }
	 
	 public boolean isEmpty() {
		 return numberOfEntries == 0;
	 }
	 
	 //start
	 public SetInterface<T> union(SetInterface<T> otherSet){
			Node currentEnd = firstNode;

	 LinkedSet <T> some = new LinkedSet<T>(); //only the types of linkedSet
		 
		 while(currentEnd != null) {
			 some.add(currentEnd.getData()); 
			 currentEnd = currentEnd.getNextNode();
		 }
	
	   currentEnd =((LinkedSet<T>) otherSet).firstNode;
	   //references firstnode, but because we were given the parameters of setInterface then we had to change its data type of linkedSet
		 
		while(currentEnd != null) {
		
		 some.add(currentEnd.getData());
		 currentEnd = currentEnd.getNextNode();
		 }
		 return some;
		 }
	 
 public SetInterface<T> intersection(SetInterface<T> otherSet){
	 LinkedSet <T> newSet = new LinkedSet<T>();

	 Node currentEnd2 = firstNode;
	 
	 //think solving in real life then convert to code 
	 while(currentEnd2 != null) { //always start with if statement
		 if(((LinkedSet<T>)otherSet).contains(currentEnd2.getData())) {
				
			 newSet.add(currentEnd2.getData());
		 }
       currentEnd2 = currentEnd2.getNextNode();	
  //keep updating to check each nodes 
	 }  
	return newSet;	 
 }
 
 
	
 public SetInterface<T> difference(SetInterface<T> otherSet){
	 LinkedSet <T> newSet1 = new LinkedSet<T>();

	 Node currentEnd3 = firstNode; //first node to get all nodes
	 
	 while(currentEnd3 != null) {
		 if(!((LinkedSet<T>)otherSet).contains(currentEnd3.getData()))
				
		 {
			 newSet1.add(currentEnd3.getData());
		 }
		 currentEnd3 = currentEnd3.getNextNode(); //get all nodes
		 
		 
	 }
	 return newSet1;
			 
			 }
			  
  //end
  private class Node {
		 private T data; // Entry in bag      
		private Node next; // Link to next node

		     private Node(T dataPortion)  {
		        this(dataPortion, null);
		     } 

		     private Node(T dataPortion, Node nextNode)
		     {
		        data = dataPortion;
		        next = nextNode;
		     } 
		     
		     private void setData(T newData) {
		    	 data = newData;
		     }
		    
		     private T getData() {
		    	 return data;
		     }
		     
		     private void setNextNode(Node nextNode) {
		    	 next = nextNode;
		     }
		     private Node getNextNode() {
		    	 return next;
		     }
 
		     
		     } 
		 }

