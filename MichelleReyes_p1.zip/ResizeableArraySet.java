package project1;
import java.util.Arrays;
 

public class ResizeableArraySet<T> implements SetInterface<T>{
	private int numOfEntries;
	private static final int DEFAULT_CAPACITY = 25;
	private T[] array;
	private boolean integrityOK = false;
	private static final int MAX_CAPACITY = 10000;

	//there is a method i didnt implement - children only do what parent is telling them
	
	private void checkIntegrity() { //check if there is an array 
	 if(!integrityOK)
	 throw new SecurityException("Array is corrupt.");
	 }
	
	 private int getIndexOf(T anEntry) {
	 int in = -1;
	 boolean there = false;
	 int index = 0;
	 while(!there && (index < numOfEntries)) {
	 if(anEntry.equals(array[index])) {
	 there = true;
	 in = index;
	 } 
	 index++;
	 } 
	 return in;
	 } 
	  
	 private T removeEntry(int givenIndex)
	 {
	 T end = null;
	 if(!isEmpty() && (givenIndex>= 0))
	 {
	 end = array[givenIndex];                   
	 array[givenIndex] = array[numOfEntries-1]; 
	 array[numOfEntries-1] = null;            
	 numOfEntries--;
	 } // end if
	 return end;
	 } 
        
	 private void checkCapacity(int done) {
		 if(done > MAX_CAPACITY) {
			 throw new IllegalStateException("Attempt to create a set whose "+
	 "capacity exeeds allowed "+
	 "maximum of "+ MAX_CAPACITY);	 
		 }
	 }
	 
	 private void doubleCapacity() {
		 int product = 2 * array.length;
		 checkCapacity(product);
		 array = Arrays.copyOf(array, product);
		
	 }
	//start of a public 
	 public ResizeableArraySet() { //Default capacity
		 integrityOK = true;
		 numOfEntries = 0;
	 @SuppressWarnings("unchecked")
	    T[] tempArray = (T[])new Object[DEFAULT_CAPACITY]; 
	 array = tempArray;
	    }
	 
  public ResizeableArraySet(int cap) { //constructors
	  integrityOK = true;
	 numOfEntries = 0;
	 @SuppressWarnings("unchecked")
	 T[] tempArray = (T[])new Object[cap];
	 array = tempArray;
	 
	 if(cap <= MAX_CAPACITY) {
		 @SuppressWarnings("unchecked")
		 T[] temp1 = (T[])new Object[cap];
		 array = temp1;
		 numOfEntries = 0;
		 integrityOK = true;
 	 }
	 else {
		 throw new IllegalStateException("Attempt to create a array whose " + "capacity exceeds allowed maximum");
	 }
 }
    
  public boolean add(T newEntry) {
  checkIntegrity();                   
  
  if(contains(newEntry)) {
	  return false;
  }
 if(array.length<= numOfEntries) {
	 doubleCapacity();
 }	 
 
  array[numOfEntries] = newEntry;
  numOfEntries++;
  return true;
}
  
   public int getCurrentSize() {
	 return numOfEntries;
    }
 
   public boolean isEmpty() {
	 return numOfEntries == 0;
     }
 

  public T remove(){
    checkIntegrity();
   T end2 = removeEntry(numOfEntries-1);
   return end2;
    } 
 
 public boolean remove(T anEntry) {
 checkIntegrity();
 int i = getIndexOf(anEntry);
 T some = removeEntry(i); 
 
return anEntry.equals(some);
 } 
        
 public void clear(){
 while(!isEmpty())
 remove();
 } 

 public boolean contains(T anEntry) {
	 checkIntegrity();
	 return getIndexOf(anEntry) > -1;
 }
 
 
	public T[] toArray() {
		@SuppressWarnings("unchecked")
		T[]yes = (T[])new Object[numOfEntries];
 for(int i = 0; i < numOfEntries; i++) {
			yes[i] = array[i];
		}
		return yes;
	}
    

 public SetInterface<T> union(SetInterface<T> otherSet){
	
	 SetInterface <T> data = new ResizeableArraySet<T>();
	 
	 for(T i : this.toArray()) {
		 data.add(i);
	 }
	  for(T i : otherSet.toArray()) {
		  data.add(i);
	  }
	 return data;
	 }
 
 public SetInterface<T> intersection(SetInterface<T> otherSet){

	 SetInterface <T> data2 = new ResizeableArraySet<T>();
	SetInterface <T> data3 = new ResizeableArraySet<T>();
	 
	 for(T i: this.toArray()) { //goes into array
	     data2.add(i); //adds array to type
	     
       if(otherSet.contains(i)) { //in those i of arrays
		  data3.add(i);
		 }
	 }
	    return data3;
	 }
	 
	 public SetInterface<T> difference(SetInterface<T> otherSet){
		 SetInterface <T> data4 = new ResizeableArraySet<T>();
		 
   for(T i: this.toArray()) {
			 data4.add(i);
		 }
	for(T i: otherSet.toArray())
			 if(data4.contains(i)) {
			 data4.remove(i);
			  } 
		 return data4;
		 }
		 
	 
 }



